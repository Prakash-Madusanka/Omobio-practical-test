<?php

        $id = $_POST['id'];
		$username = $_POST['id'];

		echo '<p>User Information</p>';

		echo 'user id is ' . $id .'</br>';
		echo 'username is ' . $username .'</br>';


?>
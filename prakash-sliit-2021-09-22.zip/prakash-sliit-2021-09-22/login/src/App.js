import React from 'react';
import {Switch,Route} from 'react-router-dom';
import Login from './ui/web/login';

const  App = () =>{
  return(
    <div>
      <switch>
        <Route exact path='/' component={Login}/>
      </switch>
    </div>
  );
}

export default App;
